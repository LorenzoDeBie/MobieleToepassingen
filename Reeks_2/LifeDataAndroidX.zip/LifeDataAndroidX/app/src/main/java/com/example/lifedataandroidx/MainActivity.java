package com.example.lifedataandroidx;


import android.os.Bundle;
import android.os.CountDownTimer;
import android.util.Log;

import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;
import androidx.databinding.ObservableField;
import androidx.databinding.ObservableInt;

import com.example.lifedataandroidx.databinding.ActivityMainBinding;


public class MainActivity extends AppCompatActivity {
    private int currentQuoteIndex;
    private QuoteDAO dao;

    public final ObservableField<String> quote = new ObservableField<>();
    public final ObservableField<String> author = new ObservableField<>();
    public final ObservableInt progress = new ObservableInt();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //setContentView(R.layout.activity_main);
        ActivityMainBinding b = DataBindingUtil.setContentView(this, R.layout.activity_main);
        b.setActivity(this);

        currentQuoteIndex = 0;
        dao = new QuoteDAO(this);
        Log.i("quote", Integer.toString(dao.size()));
        quote.set(dao.get(currentQuoteIndex).getText());
        author.set(dao.get(currentQuoteIndex).getAuthor());

        new CountDownTimer(5000, 10) {

            public void onTick(long millisUntilFinished) {
                progress.set((int)(100*(5000-millisUntilFinished)/5000));
            }

            public void onFinish() {
                currentQuoteIndex = (currentQuoteIndex+1)%dao.size();
                quote.set(dao.get(currentQuoteIndex).getText());
                author.set(dao.get(currentQuoteIndex).getAuthor());
                progress.set(0);
                this.start();

            }
        }.start();
    }
}
